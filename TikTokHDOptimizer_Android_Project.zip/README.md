# TikTok HD Optimizer (starter Android project)

This is a starter Android Studio project. It selects a video and re-encodes it as MP4 using H.264 video, AAC audio, and a 12 Mbps target video bitrate.

## Build
1. Open this folder in Android Studio.
2. Allow Gradle sync and install the Android SDK Platform 35 if prompted.
3. Connect an Android phone or start an emulator.
4. Choose **Run** to install the app.

## Important limitations
- This app cannot prevent TikTok from applying its own compression.
- Re-encoding does not restore detail that is already missing from a blurry source.
- A 12 Mbps bitrate is a starting point, not a guarantee of better TikTok quality. Very high bitrates can increase file size without improving the uploaded result.
- This starter does not yet add AI enhancement, upscale resolution, or provide a persistent export history.
- Test with copies of videos first and compare the uploaded result. Keep your original files.
