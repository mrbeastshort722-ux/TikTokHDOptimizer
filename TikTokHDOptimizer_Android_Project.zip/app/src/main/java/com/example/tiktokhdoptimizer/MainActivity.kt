package com.example.tiktokhdoptimizer

import android.app.Activity
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.media3.common.MediaItem
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import java.io.File

class MainActivity : ComponentActivity() {
    private var selectedVideo: Uri? = null
    private lateinit var status: TextView
    private lateinit var exportButton: Button
    private var transformer: Transformer? = null

    private val pickVideo = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            selectedVideo = uri
            status.text = "Video dipilih. Siap diproses."
            exportButton.isEnabled = true
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 48, 32, 32)
            gravity = Gravity.CENTER_HORIZONTAL
        }

        val title = TextView(this).apply {
            text = "TikTok HD Optimizer"
            textSize = 24f
            gravity = Gravity.CENTER
        }
        val description = TextView(this).apply {
            text = "Optimalkan video dengan encoding H.264 dan bitrate tinggi. Aplikasi ini tidak dapat mencegah TikTok mengompres video."
            textSize = 15f
            setPadding(0, 24, 0, 24)
        }
        status = TextView(this).apply {
            text = "Pilih video dari galeri untuk memulai."
            textSize = 14f
            setPadding(0, 12, 0, 24)
        }
        val chooseButton = Button(this).apply {
            text = "Pilih Video"
            setOnClickListener { pickVideo.launch(arrayOf("video/*")) }
        }
        exportButton = Button(this).apply {
            text = "Optimalkan Video"
            isEnabled = false
            setOnClickListener { exportVideo() }
        }

        layout.addView(title)
        layout.addView(description)
        layout.addView(chooseButton)
        layout.addView(exportButton)
        layout.addView(status)
        setContentView(layout)
    }

    private fun exportVideo() {
        val uri = selectedVideo ?: return
        val outputDir = getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: filesDir
        val outputFile = File(outputDir, "TikTokHD_${System.currentTimeMillis()}.mp4")

        status.text = "Sedang memproses video..."
        exportButton.isEnabled = false

        val encoderSettings = VideoEncoderSettings.Builder()
            .setBitrate(12_000_000)
            .build()

        transformer = Transformer.Builder(this)
            .setVideoMimeType("video/avc")
            .setAudioMimeType("audio/mp4a-latm")
            .setVideoEncoderSettings(encoderSettings)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    status.text = "Selesai! File tersimpan di folder Movies aplikasi."
                    exportButton.isEnabled = true
                    Toast.makeText(this@MainActivity, "Video berhasil diproses", Toast.LENGTH_LONG).show()
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    status.text = "Gagal memproses video: ${exportException.message ?: "Kesalahan tidak diketahui"}"
                    exportButton.isEnabled = true
                }
            })
            .build()

        transformer?.start(EditedMediaItem.Builder(MediaItem.fromUri(uri)).build(), outputFile.absolutePath)
    }

    override fun onStop() {
        super.onStop()
        // Export can continue while the activity remains alive; reopening the app shows no persistent progress.
    }
}
